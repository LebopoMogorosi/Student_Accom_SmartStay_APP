package com.example.gabsstudentstay

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import com.example.gabsstudentstay.navigation.AppNavigation
import com.example.gabsstudentstay.ui.theme.GABSStudentStayTheme

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {
            GABSStudentStayTheme {
                AppNavigation()
            }
        }
    }
}