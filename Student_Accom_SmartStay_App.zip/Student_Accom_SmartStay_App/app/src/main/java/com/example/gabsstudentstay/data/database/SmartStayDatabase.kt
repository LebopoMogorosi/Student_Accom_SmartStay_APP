package com.example.gabsstudentstay.data.database

import androidx.room.Database
import androidx.room.RoomDatabase
import com.example.gabsstudentstay.data.dao.ListingDao
import com.example.gabsstudentstay.data.dao.UserDao
import com.example.gabsstudentstay.data.entity.Listing
import com.example.gabsstudentstay.data.entity.User

@Database(
    entities = [User::class, Listing::class],
    version = 1,
    exportSchema = false
)
abstract class SmartStayDatabase : RoomDatabase() {

    abstract fun userDao(): UserDao

    abstract fun listingDao(): ListingDao
}