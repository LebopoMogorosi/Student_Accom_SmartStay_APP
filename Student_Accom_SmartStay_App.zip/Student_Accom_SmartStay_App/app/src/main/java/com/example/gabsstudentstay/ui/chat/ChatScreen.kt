package com.example.gabsstudentstay.ui.chat

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class ChatMessage(
    val id: String,
    val senderName: String,
    val isFromMe: Boolean,
    val text: String,
    val timestamp: String
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatScreen(
    modifier: Modifier = Modifier,
    landlordName: String = "Mr. Molosiwa (Landlord)"
) {

    var messages by remember {
        mutableStateOf(
            listOf(
                ChatMessage(
                    "1",
                    landlordName,
                    false,
                    "Hello! Thanks for inquiring about the room near UB. Is there anything specific you want to know?",
                    "09:15 AM"
                ),
                ChatMessage(
                    "2",
                    "Student",
                    true,
                    "Hi! Is water and electricity included in the monthly price?",
                    "09:17 AM"
                ),
                ChatMessage(
                    "3",
                    landlordName,
                    false,
                    "Water is included. Electricity uses a prepaid meter.",
                    "09:20 AM"
                ),
                ChatMessage(
                    "4",
                    "Student",
                    true,
                    "Can I schedule a viewing for Friday afternoon?",
                    "09:22 AM"
                )
            )
        )
    }

    var typedText by remember { mutableStateOf("") }

    val listState = rememberLazyListState()

    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.size - 1)
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = landlordName,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )

                        Text(
                            text = "Online",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                }
            )
        },
        modifier = modifier
    ) { innerPadding ->

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
        ) {

            LazyColumn(
                state = listState,
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                contentPadding = PaddingValues(
                    horizontal = 16.dp,
                    vertical = 12.dp
                ),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {

                items(
                    messages,
                    key = { it.id }
                ) { message ->

                    MessageBubble(
                        message = message
                    )
                }
            }

            Surface(
                tonalElevation = 6.dp,
                modifier = Modifier.fillMaxWidth()
            ) {

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(
                            horizontal = 12.dp,
                            vertical = 8.dp
                        )
                        .navigationBarsPadding()
                        .imePadding(),
                    verticalAlignment = Alignment.CenterVertically
                ) {

                    OutlinedTextField(
                        value = typedText,
                        onValueChange = {
                            typedText = it
                        },
                        placeholder = {
                            Text("Type your message...")
                        },
                        maxLines = 4,
                        shape = RoundedCornerShape(24.dp),
                        modifier = Modifier
                            .weight(1f)
                            .padding(end = 8.dp)
                    )

                    IconButton(
                        onClick = {

                            if (typedText.isNotBlank()) {

                                val currentTime =
                                    SimpleDateFormat(
                                        "hh:mm a",
                                        Locale.getDefault()
                                    ).format(Date())

                                val newMessage = ChatMessage(
                                    id = System.currentTimeMillis().toString(),
                                    senderName = "Student",
                                    isFromMe = true,
                                    text = typedText.trim(),
                                    timestamp = currentTime
                                )

                                messages = messages + newMessage
                                typedText = ""
                            }
                        },
                        enabled = typedText.isNotBlank()
                    ) {

                        Icon(
                            imageVector = Icons.Default.Send,
                            contentDescription = "Send Message"
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun MessageBubble(
    message: ChatMessage
) {

    val bubbleAlignment =
        if (message.isFromMe)
            Alignment.CenterEnd
        else
            Alignment.CenterStart

    val bubbleColor =
        if (message.isFromMe)
            MaterialTheme.colorScheme.primary
        else
            MaterialTheme.colorScheme.surfaceVariant

    val textColor =
        if (message.isFromMe)
            MaterialTheme.colorScheme.onPrimary
        else
            MaterialTheme.colorScheme.onSurfaceVariant

    val bubbleShape =
        if (message.isFromMe) {
            RoundedCornerShape(
                topStart = 16.dp,
                topEnd = 16.dp,
                bottomStart = 16.dp,
                bottomEnd = 0.dp
            )
        } else {
            RoundedCornerShape(
                topStart = 16.dp,
                topEnd = 16.dp,
                bottomStart = 0.dp,
                bottomEnd = 16.dp
            )
        }

    Box(
        modifier = Modifier.fillMaxWidth(),
        contentAlignment = bubbleAlignment
    ) {

        Column(
            horizontalAlignment =
                if (message.isFromMe)
                    Alignment.End
                else
                    Alignment.Start,
            modifier = Modifier.fillMaxWidth(0.8f)
        ) {

            Box(
                modifier = Modifier
                    .clip(bubbleShape)
                    .background(bubbleColor)
                    .padding(
                        horizontal = 12.dp,
                        vertical = 8.dp
                    )
            ) {

                Text(
                    text = message.text,
                    style = MaterialTheme.typography.bodyLarge,
                    color = textColor
                )
            }

            Spacer(
                modifier = Modifier.height(2.dp)
            )

            Text(
                text = message.timestamp,
                style = MaterialTheme.typography.labelSmall,
                modifier = Modifier.padding(horizontal = 4.dp)
            )
        }
    }
}