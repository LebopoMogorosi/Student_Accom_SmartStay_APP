package com.example.gabsstudentstay.data.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import com.example.gabsstudentstay.data.entity.Listing

@Dao
interface ListingDao {

    @Insert
    suspend fun insertListing(listing: Listing)

    @Query("SELECT * FROM listings")
    suspend fun getAllListings(): List<Listing>

    @Query("SELECT * FROM listings WHERE status = 'Available'")
    suspend fun getAvailableListings(): List<Listing>

    @Query("UPDATE listings SET status = :status WHERE id = :listingId")
    suspend fun updateListingStatus(listingId: Long, status: String)

    @Query("SELECT * FROM listings WHERE location LIKE '%' || :location || '%'")
    suspend fun filterByLocation(location: String): List<Listing>
}