package com.example.gabsstudentstay.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "listings")
data class Listing(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val title: String,
    val priceBWP: Double,
    val location: String,
    val propertyType: String,
    val amenities: String,
    val availabilityDate: String,
    val depositAmount: Double,
    val imageUrl: String,
    val status: String
)