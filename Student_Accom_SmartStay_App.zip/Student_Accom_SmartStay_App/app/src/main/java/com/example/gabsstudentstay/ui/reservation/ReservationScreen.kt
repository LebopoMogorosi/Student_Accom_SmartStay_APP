package com.example.gabsstudentstay.ui.reservation

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.gabsstudentstay.data.entity.Listing
import kotlin.random.Random

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReservationScreen(
    listing: Listing,
    onReservationComplete: (String) -> Unit
) {

    var currentStatus by remember { mutableStateOf(listing.status) }
    var paymentAmount by remember { mutableStateOf("") }
    var paymentError by remember { mutableStateOf<String?>(null) }
    var paymentSuccessful by remember { mutableStateOf(false) }
    var referenceNumber by remember { mutableStateOf("") }

    fun generateReference(): String {
        return "RES-2026-${Random.nextInt(10000, 99999)}"
    }

    fun processPayment() {
        val amount = paymentAmount.toDoubleOrNull()

        if (amount == null) {
            paymentError = "Enter a valid payment amount"
            return
        }
    }
}


