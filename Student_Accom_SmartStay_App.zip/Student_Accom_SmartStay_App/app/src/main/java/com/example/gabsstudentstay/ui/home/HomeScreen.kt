package com.example.gabsstudentstay.ui.home

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.gabsstudentstay.data.entity.Listing

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    listings: List<Listing>,
    onReserveClick: (Listing) -> Unit
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text("SmartStay Accommodation")
                }
            )
        }
    ) { paddingValues ->

        if (listings.isEmpty()) {

            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues),
                contentAlignment = Alignment.Center
            ) {
                Text("No accommodation listings available.")
            }

        } else {

            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {

                items(listings) { listing ->

                    AccommodationCard(
                        listing = listing,
                        onReserveClick = {
                            onReserveClick(listing)
                        }
                    )
                }
            }
        }
    }
}

@Composable
fun AccommodationCard(
    listing: Listing,
    onReserveClick: () -> Unit
) {

    Card(
        modifier = Modifier.fillMaxWidth(),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
    ) {

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {

            Text(
                text = listing.title,
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold
            )

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = "BWP ${listing.priceBWP}",
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.primary
            )

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.LocationOn,
                    contentDescription = "Location"
                )

                Spacer(modifier = Modifier.width(4.dp))

                Text(text = listing.location)
            }

            Spacer(modifier = Modifier.height(6.dp))

            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.DateRange,
                    contentDescription = "Availability"
                )

                Spacer(modifier = Modifier.width(4.dp))

                Text(
                    text = "Available: ${listing.availabilityDate}"
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = "Type: ${listing.propertyType}"
            )

            Text(
                text = "Deposit: BWP ${listing.depositAmount}"
            )

            Text(
                text = "Status: ${listing.status}",
                color = if (listing.status == "Available")
                    MaterialTheme.colorScheme.primary
                else
                    MaterialTheme.colorScheme.error
            )

            Spacer(modifier = Modifier.height(12.dp))

            Button(
                onClick = onReserveClick,
                enabled = listing.status == "Available",
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Reserve Room")
            }
        }
    }
}